import sys
import xbmcplugin
import xbmcgui
from .plugin2 import Myaddon


class Player(Myaddon):
    
    def play_video(self, name, url, icon, description, resolve=True):
           if url is None:
               return
           link = url
           if type(link) == list:
               if len(link) > 1:
                   link = self.get_multilink(link)
               elif len(link) == 1:
                   if len(link[0]) == 2:
                       link = link[0][1]
                   elif len(link[0]) == 1:
                       link = link[0]
               else:
                   return
           if not link:
               return
           if link.endswith(')'):
               link = link.split('(')[0]
           if resolve is True:
               import resolveurl
               if resolveurl.HostedMediaFile(link).valid_url():
                   link = resolveurl.HostedMediaFile(link).resolve()
           liz = xbmcgui.ListItem(name, path=link)
           self.set_info(liz, {'title': name, 'plot':description})
           liz.setArt({'thumb': icon, 'icon': icon, 'poster': icon})
           liz.setProperty('IsPlayable', 'true')
           xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, liz)

player = Player()
