import sys
from resources.lib.modules.addon import router

if __name__=='__main__':
    router(sys.argv[2][1:])