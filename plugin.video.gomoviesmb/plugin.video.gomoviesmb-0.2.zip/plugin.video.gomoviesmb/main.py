# -*- coding: UTF-8 -*-

import sys, os, re, json, base64
if sys.version_info >= (3,0,0):
# for Python 3
    to_unicode = str
    from resources.lib.cmf3 import parseDOM
    from resources.lib.cmf3 import replaceHTMLCodes
    from urllib.parse import unquote, parse_qs, parse_qsl, quote, urlencode, quote_plus

else:
    # for Python 2
    to_unicode = unicode
    from resources.lib.cmf2 import parseDOM
    from resources.lib.cmf2 import replaceHTMLCodes
    from urllib import unquote, quote, urlencode, quote_plus
    from urlparse import parse_qsl, parse_qs

import io

from resources.lib import recaptcha_v2

import xbmc, xbmcvfs

import requests
import xbmcgui
import xbmcplugin
import xbmcaddon

import resolveurl 

#urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.gomoviesmb')

PATH            = addon.getAddonInfo('path')
try:
    DATAPATH        = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
except:
    DATAPATH    = xbmc.translatePath(addon.getAddonInfo('profile')).decode('utf-8')
    
if not os.path.exists(DATAPATH):
    os.makedirs(DATAPATH)
    
jfilename = os.path.join(DATAPATH,'jfilename')
napisy = os.path.join(DATAPATH,'napisy')


RESOURCES       = PATH+'/resources/'
ikona = RESOURCES+'../icon.png'
FANART=RESOURCES+'fanart.jpg'

exlink = params.get('url', None)
nazwa= params.get('title', None)
rys = params.get('image', None)
page = params.get('page',[1])[0]


fkatv = addon.getSetting('fkatV')
fkatn = addon.getSetting('fkatN') if fkatv else 'all'

fkrajv = addon.getSetting('fkrajV')
fkrajn = addon.getSetting('fkrajN') if fkrajv else 'all'

frokv = addon.getSetting('frokV')
frokn = addon.getSetting('frokN') if frokv else 'all'

fqualv = addon.getSetting('fqualV')
fqualn = addon.getSetting('fqualN') if fqualv else 'all'

squalv = addon.getSetting('squalV')
squaln = addon.getSetting('squalN') if squalv else 'all'

skatv = addon.getSetting('skatV')
skatn = addon.getSetting('skatN') if skatv else 'all'

skrajv = addon.getSetting('skrajV')
skrajn = addon.getSetting('skrajN') if skrajv else 'all'

srokv = addon.getSetting('srokV')
srokn = addon.getSetting('srokN') if srokv else 'all'

dataf =  addon.getSetting('fdata')    
datas =  addon.getSetting('sdata') 
   
wybor = addon.getSetting('subs')
wybor = addon.setSetting('subs', 'NO') if not wybor else wybor
wybornapisow = True

UA='Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:85.0) Gecko/20100101 Firefox/85.0'

headers = {
    'User-Agent': UA,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'TE': 'Trailers',
}
sess = requests.Session()
def build_url(query):
    return base_url + '?' + urlencode(query)

def add_item(url, name, image, mode, folder=False, IsPlayable=False, infoLabels=False, movie=True,itemcount=1, page=1,fanart=FANART,moviescount=0):
    list_item = xbmcgui.ListItem(label=name)

    if IsPlayable:
        list_item.setProperty("IsPlayable", 'True')
    if not infoLabels:
        infoLabels={'title': name,'plot':name}
    list_item.setInfo(type="video", infoLabels=infoLabels)    
    list_item.setArt({'thumb': image, 'poster': image, 'banner': image, 'icon': image, 'fanart': FANART})
    ok=xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url = build_url({'mode': mode, 'url' : url, 'page' : page, 'moviescount' : moviescount,'movie':movie,'title':name,'image':image}),            
        listitem=list_item,
        isFolder=folder)
    xbmcplugin.addSortMethod(addon_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
    return ok
    
def menuMovies():
	add_item('https://gomovies.sx/filter?type=movie', 'List movies', 'DefaultMovies.png', "listmovies", True)    
	add_item('', "-      [COLOR lightblue]quality:[/COLOR] [B]"+fqualn+'[/B]','DefaultRecentlyAddedMovies.png', 'filtr:fqual', folder=False,fanart='')
	add_item('', "-      [COLOR lightblue]released:[/COLOR] [B]"+frokn+'[/B]','DefaultRecentlyAddedMovies.png', 'filtr:frok', folder=False,fanart='')
	add_item('', "-      [COLOR lightblue]genre:[/COLOR] [B]"+fkatn+'[/B]','DefaultRecentlyAddedMovies.png', 'filtr:fkat', folder=False,fanart='')
	add_item('', "-      [COLOR lightblue]country:[/COLOR] [B]"+fkrajn+'[/B]','DefaultRecentlyAddedMovies.png', 'filtr:fkraj', folder=False,fanart='')

	add_item('', '[COLOR lightblue]Search[/COLOR]', 'DefaultAddonsSearch.png', "search", True)    
	add_item('f', "[I][COLOR violet][B]Reset all filters[/COLOR][/I][/B]",'DefaultAddonService.png', "resetfil", folder=False)
	
	xbmcplugin.endOfDirectory(addon_handle)
    
def menuTVshows():
    add_item('https://gomovies.sx/filter?type=tv', 'List tv-series', 'DefaultMovies.png', "listmovies", True)    
    add_item('', "-      [COLOR lightblue]quality:[/COLOR] [B]"+squaln+'[/B]','DefaultRecentlyAddedMovies.png', 'filtr:squal', folder=False,fanart='')
    add_item('', "-      [COLOR lightblue]released:[/COLOR] [B]"+srokn+'[/B]','DefaultRecentlyAddedMovies.png', 'filtr:srok', folder=False,fanart='')
    add_item('', "-      [COLOR lightblue]genre:[/COLOR] [B]"+skatn+'[/B]','DefaultRecentlyAddedMovies.png', 'filtr:skat', folder=False,fanart='')
    add_item('', "-      [COLOR lightblue]country:[/COLOR] [B]"+skrajn+'[/B]','DefaultRecentlyAddedMovies.png', 'filtr:skraj', folder=False,fanart='')

    
    
    add_item('s', "[I][COLOR violet][B]Reset all filters[/COLOR][/I][/B]",'DefaultAddonService.png', "resetfil", folder=False)
    add_item('', '[COLOR lightblue]Search[/COLOR]', 'DefaultAddonsSearch.png', "search", True)    
    xbmcplugin.endOfDirectory(addon_handle)
def home():
	add_item('https://gomovies.sx', 'Movies', 'DefaultMovies.png', "menumov", True)    
	add_item('https://gomovies.sx', 'TV-Series', 'DefaultMovies.png', "menutvs", True)    
	add_item('', '[COLOR lightblue]Search[/COLOR]', 'DefaultAddonsSearch.png', "search", True)    
	xbmcplugin.endOfDirectory(addon_handle) 
def ListMovies(exlink,page):

    links, serials, pagin = getMovies(exlink,page)

    itemz=links
    items = len(links)
    mud='getLinks'
    fold=True
    for f in itemz:
        add_item(name=f.get('title'), url=f.get('href'), mode=mud, image=f.get('img'), folder=fold, infoLabels={'plot':f.get('title'),'title':f.get('title')}, itemcount=items, IsPlayable=False)    
    itemz=serials
    items = len(serials)
    mud='getseasons'
    fold=True
    for f in itemz:
        add_item(name=f.get('title'), url=f.get('href'), mode=mud, image=f.get('img'), folder=fold, infoLabels={'plot':f.get('title'),'title':f.get('title')}, itemcount=items)    
    
    if pagin:
        add_item(name='[COLOR blue]>> Nastepna strona [/COLOR]', url=exlink, mode='listmovies', image='', folder=True, page=pagin)
    if links or serials:
        xbmcplugin.setContent(addon_handle, 'videos')    

        xbmcplugin.endOfDirectory(addon_handle)        

def getMovies(url,page=1):

	if '/filter?type=' in url:
		datax = datas if '?type=tv&' in url else dataf
	
		if '&page=' in url:
		
			url = re.sub('\&page=\\d+','&page=%d'%int(page),url)
		else:
		
			url = url +datax+ '&page=%d' %int(page)
		nturl = '&page=%d"' %(int(page)+1) 	
	else:
		if '?page=' in url:
		
			url = re.sub('\?page=\\d+','?page=%d'%int(page),url)
		else:
		
			url = url +'?page=%d' %int(page)
		nturl = '?page=%d"' %(int(page)+1) 

	r = sess.get(url,verify=False, headers=headers)
	html=r.content
	if sys.version_info >= (3,0,0):
		html = html.decode(encoding='utf-8', errors='strict')
	out=[]
	serout=[]
	
	npage=False

	pagination = parseDOM(html, 'nav', attrs={'aria-label': "Page navigation"}) 
	if pagination:
		npage = str(int(page)+1)if nturl in pagination[0] else False

	result = parseDOM(html, 'div', attrs={'class': "film_list\-wrap"})
	result = result[0] if result else html
	ids = [(a.start(), a.end()) for a in re.finditer('<div class="flw-item"', result)]
	ids.append( (-1,-1) )
	out=[]
	serout=[]
	
	for i in range(len(ids[:-1])):
		link = result[ ids[i][1]:ids[i+1][0] ]
	
		imag= parseDOM(link, 'img', ret='src')[0]
		imag = 'https:'+imag if imag.startswith('//') else imag
		title= parseDOM(link, 'a', ret='title')
		title = title[0] if title else parseDOM(link, 'a')[1]
		href = parseDOM(link, 'a', ret='href')[0]
		href = 'https://gomovies.sx' +href if href.startswith('/') else href
		if '/tv/' in href:
			title = title+' [COLOR gold] (tv show)[/COLOR]'
		id = href.split('-')[-1]
		title = title.replace('&#39;',"'").replace('&#38;',"&")
		
		plot =''

		genre =''
		code =''
		year = parseDOM(link, 'span', attrs={'class': "fdi-item"})
		year = year[0] if year else ''
		if '?type=tv&' in url or '/tv/' in href:
			serout.append({'title':PLchar(title),'href':href+'|'+id,'img':imag,'plot':PLchar(plot),'genre':genre,'year':year,'code':code})
		else:
			out.append({'title':PLchar(title),'href':href+'|'+id,'img':imag,'plot':PLchar(plot),'genre':genre,'year':year,'code':code})
	return (out,serout, npage) 

	
def getLinks(exlink):
	href,id = exlink.split('|')

	html = sess.get(href, headers=headers, verify=False).content
	if sys.version_info >= (3,0,0):
		html = html.decode(encoding='utf-8', errors='strict')
	
	url2 = "https://gomovies.sx/ajax/episode/list/"+id
	if '.sx/tv/' in href:
		url2 = "https://gomovies.sx/ajax/episode/servers/"+id
	headers.update({'Referer': href})
	html2 = sess.get(url2, headers=headers, verify=False).content
	if sys.version_info >= (3,0,0):
		html2 = html2.decode(encoding='utf-8', errors='strict')

	servers = parseDOM(html2, 'li', attrs={'class': "nav-item"})	
	
	details = parseDOM(html, 'div', attrs={'class': "detail_page.*?"})[0]
	
	imag = parseDOM(details, 'img', ret='src')[0]
	tytx = parseDOM(parseDOM(details, 'h2')[0],'a')[0]
	qual = re.findall('quality\s*"\s*>(.*?)<\/strong>',details)
	qual = re.sub("<[^>]*>","",qual[0].strip())
	description = parseDOM(details, 'div', attrs={'class': "description"})
	description = description[0] if description else tyt
	description = description.replace('\n','')
	infol = {'plot':description,'code':qual}
	add_item(name="[COLOR gold]Subtitles if available:[/COLOR] [B]"+wybor+"[/B]", url='xx', mode='sett', image=ikona, folder=False, infoLabels={'plot':'fbox.to'}, IsPlayable=False)
	if '.sx/tv/' in href:
		for x in servers:
			ac=''
			host = re.findall('<span>([^>]+)<\/span',x,re.DOTALL)[0]
			linkid = re.findall('data-id\s*=\s*"([^"]+)"',x,re.DOTALL)[0]

			tyt = tytx + ' - ' +nazwa +' - [I][COLOR khaki]'+host+'[/I] '+' [B][/COLOR][/B]'
			
			add_item(name=tyt, url=linkid+'|'+href, mode='playlink', image=imag, folder=False, infoLabels=infol, IsPlayable=True)
	else:
		for x in servers:
			ac=''
			host = re.findall('title\s*=\s*"([^"]+)">',x,re.DOTALL)[0]
			linkid = re.findall('linkid\s*=\s*"([^"]+)"',x,re.DOTALL)[0]
			refer = re.findall('href\s*=\s*"([^"]+)"',x,re.DOTALL)[0]
			tyt = tytx+' - [I][COLOR khaki]'+host+'[/I] '+' [B][/COLOR][/B]'
			
			add_item(name=tyt, url=linkid+'|'+refer, mode='playlink', image=imag, folder=False, infoLabels=infol, IsPlayable=True)

	if len(servers)>0:
	
		xbmcplugin.setContent(addon_handle, 'videos')
		xbmcplugin.endOfDirectory(addon_handle)	
	else:
		xbmcgui.Dialog().notification('[B]Error[/B]', 'Links are not available.',xbmcgui.NOTIFICATION_INFO, 8000,False)
			
			
			

def dec(chra):

    try:    
        if sys.version_info >= (3,0,0):
            chra =repr(chra.encode('utf-8'))
            chra = chra.replace('\\xc3\\xaa','ę').replace('\\xc3\\x8a','Ę')
            chra = chra.replace('\\xc3\\xa6','ć').replace('\\xc3\\x86','Ć')
            chra = chra.replace('\\xc2\\xbf','ż').replace('\\xc2\\x9f','Ż')
            chra = chra.replace('\\xc2\\xb9','ą').replace('\\xc2\\x99','Ą')
            
            chra = chra.replace('\\xc5\\x93','ś').replace('\\xc5\\x92','Ś')
            chra = chra.replace('\\xc3\\xb3','ó').replace('\\xc3\\x93','Ó')
            
            chra = chra.replace('\\xc5\\xb8','ź').replace('\\xc5\\xb7','Ź')
            
            chra = chra.replace('\\xc2\\xb3','ł').replace('\\xc2\\x93','Ł')
            
            chra = chra.replace('\\xc3\\xb1','ń').replace('\\xc3\\x91','Ń')
            chra = chra .replace("b\'",'')

            chra = chra .replace("\\n",'\n').replace("\\r",'\r') 
            chra = chra .replace("\\'","'")

        else:

            chra = chra.replace('\xc3\xaa','ę').replace('\xc3\x8a','Ę')
            chra = chra.replace('\xc3\xa6','ć').replace('\xc3\x86','Ć')
            chra = chra.replace('\xc2\xbf','ż').replace('\xc2\x9f','Ż')
            chra = chra.replace('\xc2\xb9','ą').replace('\xc2\x99','Ą')
            
            chra = chra.replace('\xc5\x93','ś').replace('\xc5\x92','Ś')
            chra = chra.replace('\xc3\xb3','ó').replace('\xc3\x93','Ó')
            
            chra = chra.replace('\xc5\xb8','ź').replace('\xc5\xb7','Ź')
            
            chra = chra.replace('\xc2\xb3','ł').replace('\xc2\x93','Ł')
            
            chra = chra.replace('\xc3\xb1','ń').replace('\xc3\x91','Ń')



    except:
        pass
        
    return chra
    
def transPolish(subtlink):

    try:
        response = sess.get(subtlink, headers=headers, verify=False)

        if sys.version_info >= (3,0,0):
        
            response  = response.text
        else:
            response  = response.content
        gg=dec(response)

        open(napisy, 'w').write(gg)

        return True
    except:
        return False

def decodeSource(sources):
	from resolveurl.lib.pyaes import openssl_aes
	response = requests.get("https://raw.githubusercontent.com/enimax-anime/key/e4/key.txt")
	key = response.text
	table = json.loads(key)
	decrypted_key = ""
	offset = 0
	encrypted_string = sources
	for start, end in table:
		decrypted_key += encrypted_string[start - offset:end - offset]
		encrypted_string = encrypted_string[:start - offset] + encrypted_string[end - offset:]
		offset += end - start
	
	OpenSSL_AES = openssl_aes.AESCipher()
	sources = json.loads(OpenSSL_AES.decrypt(encrypted_string, decrypted_key))	
	return sources
	
def PlayLink(exlink):

	id,ref = exlink.split('|')
	ref = 'https://gomovies.sx' + ref if ref.startswith('/') else ref
	headers.update({'Referer': ref})

	response = sess.get('https://gomovies.sx/ajax/sources/'+id, headers=headers, verify=False)
	
	html = response.content

	if sys.version_info >= (3,0,0):
		html = html.decode(encoding='utf-8', errors='strict')

		
		
	tracks = None	
	link = re.findall('"link"\s*\:\s*"([^"]+)"', html,re.DOTALL)[0]
	if 'rabbitstream' in link:
		nturl = link.replace('/embed-4/','/ajax/embed-4/getSources?id=')
		if '?z=' in nturl:
			nturl = nturl.split('?z=')[0]
		headers.update({'Referer': link,'X-Requested-With': 'XMLHttpRequest'})
		response = sess.get(nturl, headers=headers, verify=False)
	
		html = response.content
	
		if sys.version_info >= (3,0,0):
			html = html.decode(encoding='utf-8', errors='strict')
		
		jsdata = json.loads(html)
		sources = jsdata.get('sources', None)
		tracks = jsdata.get('tracks', None)

		src = decodeSource(sources)	

		stream_url = src[0].get('file', None)
	
	else:
		try:
			stream_url = resolveurl.resolve(link)
		except Exception as som:
			xbmcgui.Dialog().notification('[B]Resolveurl error[/B]', str(som),xbmcgui.NOTIFICATION_INFO, 8000,False)
			quit()
	subsout=[]

	subt = False
	if wybor == 'YES':
		for subtitle in tracks:
			if subtitle.get('kind',None) == 'captions':
				subt = subtitle.get('src',None)
				subt2 = subtitle.get('file',None)
				subt = subt if subt else subt2
				label = subtitle.get('label',None)
				subsout.append({'label':label,'subt':subt})
	if wybor == 'YES' and subsout:
		labels = [x.get('label') for x in subsout]
		sel = xbmcgui.Dialog().select('Subtitle language',labels)	
		if sel>-1:
			subt=subsout[sel].get('subt')
			if subsout[sel].get('label') == 'Polish':
			
				subt = napisy if transPolish(subt) else subt
				
		else:
			subt = False

	if stream_url:
		
		play_item = xbmcgui.ListItem(path=stream_url)
	
		if subt:
			play_item.setSubtitles([subt])
		xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def ListEpisodes(exlink):

    links= getEpisodes(exlink)    
    items = len(links)
    for f in links:
        add_item(name=f.get('title'), url=f.get('href'), mode='getLinks', image=f.get('img'), folder=True, infoLabels= f.get('infol'), itemcount=items, IsPlayable=True)        
    xbmcplugin.setContent(addon_handle, 'files')    

    xbmcplugin.endOfDirectory(addon_handle)    
    
def getEpisodes(urlid):
	href,seas_id = urlid.split('|')

	infolab =  getInfolab(href)
	tyt = infolab.get('title')
	pic = infolab.get('imag')
	infolab.pop('imag')
	infolab.pop('title')
	headers.update({'Referer': href})
	html = sess.get('https://gomovies.sx/ajax/season/episodes/'+seas_id, headers=headers, verify=False).content
	zz=''
	if sys.version_info >= (3,0,0):
		html = html.decode(encoding='utf-8', errors='strict')
	
	seas = re.findall('eason\s*(\d+)',nazwa)
	sez = 'S%02d - '%(int(seas[0])) if seas else ''
	out = []
	episodes = parseDOM(html, 'li', attrs={'class': "nav-item"})
	for epis in episodes:
		epi_id = parseDOM(epis, 'a', ret='data-id')[0] 
		title = parseDOM(epis, 'a', ret='title')[0]
		title = title.replace('&#39;',"'").replace('&#38;',"&")
		out.append({'title':sez+title ,'href':href+'|'+epi_id,'img':pic, 'infol':infolab})
	
	return out

def ListSeasons(exlink):

    links= getSerial(exlink)    
    items = len(links)
    for f in links:
        add_item(name=f.get('title'), url=f.get('href'), mode='getEpisodes', image=f.get('img'), folder=True, infoLabels= f.get('infol'), itemcount=items, IsPlayable=True)        
    xbmcplugin.setContent(addon_handle, 'files')    

    xbmcplugin.endOfDirectory(addon_handle)  
	
def getInfolab(url):
	headers.update({'Referer': url})
	html = sess.get(url, headers=headers, verify=False).content
	zz=''
	if sys.version_info >= (3,0,0):
		html = html.decode(encoding='utf-8', errors='strict')
	
	details = parseDOM(html, 'div', attrs={'class': "detail_page.*?"})[0]
	
	imag = parseDOM(details, 'img', ret='src')[0]
	tytx = parseDOM(parseDOM(details, 'h2')[0],'a')[0]
	qual = re.findall('quality\s*"\s*>(.*?)<\/strong>',details)
	qual = re.sub("<[^>]*>","",qual[0].strip())
	description = parseDOM(details, 'div', attrs={'class': "description"})
	description = description[0] if description else tyt
	description = description.replace('\n','')
	description = description.replace('&#39;',"'").replace('&#38;',"&")
	infol = {'title':tytx, 'plot':description,'code':qual, 'imag':imag}
	return infol
	
def getSerial(href):

	out=[]
	href,id = href.split('|')
	infolab =  getInfolab(href)
	headers.update({'Referer': href})
	nturl = 'https://gomovies.sx/ajax/season/list/'+id
	
	html = sess.get(nturl, headers=headers, verify=False).content
	
	if sys.version_info >= (3,0,0):
		html = html.decode(encoding='utf-8', errors='strict')
		
	sezony = re.findall('new">(.*?)<\/div>', html,re.DOTALL)[0]
	tyt = infolab.get('title')
	pic = infolab.get('imag')
	infolab.pop('imag')
	infolab.pop('title')
	out=[]
	for seas_id,seas in re.findall('\-(\d+)">([^<]+)<',sezony,re.DOTALL):
		out.append({'title':tyt + ' - ' +seas,'href':href+'|'+seas_id,'img':pic,'infol':infolab})
	return out


def PLchar(char):
    if type(char) is not str:
        char=char.encode('utf-8')
    char = char.replace('\\u0105','\xc4\x85').replace('\\u0104','\xc4\x84')
    char = char.replace('\\u0107','\xc4\x87').replace('\\u0106','\xc4\x86')
    char = char.replace('\\u0119','\xc4\x99').replace('\\u0118','\xc4\x98')
    char = char.replace('\\u0142','\xc5\x82').replace('\\u0141','\xc5\x81')
    char = char.replace('\\u0144','\xc5\x84').replace('\\u0144','\xc5\x83')
    char = char.replace('\\u00f3','\xc3\xb3').replace('\\u00d3','\xc3\x93')
    char = char.replace('\\u015b','\xc5\x9b').replace('\\u015a','\xc5\x9a')
    char = char.replace('\\u017a','\xc5\xba').replace('\\u0179','\xc5\xb9')
    char = char.replace('\\u017c','\xc5\xbc').replace('\\u017b','\xc5\xbb')
    char = char.replace('&#8217;',"'")
    char = char.replace('&#8211;',"-")    
    char = char.replace('&#8230;',"...")    
    char = char.replace("&gt;",">")    
    char = char.replace("&Iacute;","Í").replace("&iacute;","í")
    char = char.replace("&icirc;","î").replace("&Icirc;","Î")
    char = char.replace('&oacute;','ó').replace('&Oacute;','Ó')
    char = char.replace('&quot;','"').replace('&amp;quot;','"')
    char = char.replace('&bdquo;','"').replace('&rdquo;','"')
    char = char.replace("&Scaron;","Š").replace("&scaron;","š")
    char = char.replace("&ndash;","-").replace("&mdash;","-")
    char = char.replace("&Auml;","Ä").replace("&auml;","ä")

    char = char.replace('&#8217;',"'")
    char = char.replace('&#8211;',"-")    
    char = char.replace('&#8230;',"...")    
    char = char.replace('&#8222;','"').replace('&#8221;','"')    
    char = char.replace('[&hellip;]',"...")
    char = char.replace('&#038;',"&")    
    char = char.replace('&#039;',"'")
    char = char.replace('&quot;','"')
    char = char.replace('&nbsp;',".").replace('&amp;','&')
    
    
    
    char = char.replace('Napisy PL',"[COLOR lightblue](napisy pl)[/COLOR]")
    char = char.replace('Lektor PL',"[COLOR lightblue](lektor pl)[/COLOR]")
    char = char.replace('Dubbing PL',"[COLOR lightblue](dubbing pl)[/COLOR]")    
    return char    

    
def router(paramstring):
	args = dict(parse_qsl(paramstring))
	
	if args:
		mode = args.get('mode', None)
	
		if mode == 'listmovies':
			ListMovies(exlink,page)
		elif mode == 'getLinks':
			getLinks(exlink)    
		elif mode == 'playlink':
			PlayLink(exlink)
			
		elif mode == 'menumov':
			menuMovies()
		elif mode == 'menutvs':
			menuTVshows()
			
		elif 'filtr' in mode:
			ff = mode.split(':')[1]
			
			if 'kraj' in ff:
				dd='country:'
				value=["all","11","151","4","44","190","147","101","231","222","158","3","96","93","72","105","196","24","205","173","91","40","172","122","219","23","170","109","200","135","62","114","41","119","57","180","129"]
				label=['all',"argentina","australia","austria","belgium","brazil","canada","china","czech republic","denmark","finland","france","germany","hong kong","hungary","india","ireland","israel","italy","japan","luxembourg","mexico","netherlands","new zealand","norway","poland","romania","russia","south africa","south korea","spain","sweden","switzerland","taiwan","thailand","united kingdom","united states of america"]

			elif 'qual' in ff:
				dd='quality:'
				value=["all","HD","SD","CAM"]
				label=['all',"hd","sd","cam"]

			elif 'rok' in ff:
				dd='year:'
				label=['all',"2023","2022","2021","2020","2019","older"]
				value=['all',"2023","2022","2021","2020","2019","older-2019"]
				
			elif 'kat' in ff:
				dd='genre:'
				value=["all","10","24","18","3","37","7","2","11","4","9","13","19","14","27","15","1","34","22","12","31","5","35","29","16","8","17","28","6"]
				label=["all","action","action&adventure","adventure","animation","biography","comedy","crime","documentary","drama","family","fantasy","history","horror","kids","music","mystery","news","reality","romance","sci-fi&fantasy","science fiction","soap","talk","thriller","tv movie","war","war&politics","western"]
				

			if 'rok' in ff or 'qual' in ff:
				sel = xbmcgui.Dialog().select('Select '+dd,label)
			else:
			
				sel = xbmcgui.Dialog().multiselect('Select '+dd,label)
			if sel!=-1:

				if isinstance(sel,list):
					
					if 0 in sel: sel=[0]
					v = '%s'%('-'.join( [ value[i] for i in sel])) if sel[0]!=0 else 'all'
					
					n = ', '.join( [ label[i] for i in sel])
				else:
					sel = sel if sel>-1 else quit()
					v = '%s'%value[sel] if value[sel] else ''
					n = label[sel]
				if 'kraj' in ff:
					v = '&country='+v
				elif 'rok' in ff:
					v = '&release_year='+v
				elif 'kat' in ff:
					v = '&genre='+v
				elif 'qual' in ff:
					v = '&quality='+v
					
				addon.setSetting(ff+'V',v)
				addon.setSetting(ff+'N',n)

				fkatv = addon.getSetting('fkatV')
				
				fkrajv = addon.getSetting('fkrajV')
				
				frokv = addon.getSetting('frokV')
				
				fwerv = addon.getSetting('fqualV')
				
				skatv = addon.getSetting('skatV')
				
				skrajv = addon.getSetting('skrajV')
				
				srokv = addon.getSetting('srokV')
				

				dataf=fqualv+frokv+fkatv+fkrajv
				datas=squalv+srokv+skatv+skrajv
				
				addon.setSetting('fdata',dataf)
				addon.setSetting('sdata',datas)
				xbmc.executebuiltin('Container.Refresh')
			else:
				quit()
		elif mode =='getseasons':
			ListSeasons(exlink)
		
		elif mode =='getEpisodes':
			ListEpisodes(exlink)
	
		elif mode == 'getLinksSerial':
			getLinksSerial(exlink)
		
		elif mode == "resetfil":

			addon.setSetting(exlink+'katN','all')
			addon.setSetting(exlink+'katV','&genre=all')
			
			addon.setSetting(exlink+'krajN','all')
			addon.setSetting(exlink+'krajV','&country=all')
			
			addon.setSetting(exlink+'rokN','all')
			addon.setSetting(exlink+'rokV','&release_year=all')
			
			addon.setSetting(exlink+'qualN','all')
			addon.setSetting(exlink+'qualV','&quality=all')
			

			addon.setSetting(exlink+'data','&quality=all&release_year=all&genre=all&country=all')
			xbmc.executebuiltin("Container.Refresh") 
			
		elif mode=='search':
			query = xbmcgui.Dialog().input(u'Search...', type=xbmcgui.INPUT_ALPHANUM)
			if query:      
				url = 'https://gomovies.sx/search/'+query.replace(' ','+')
				ListMovies(url,'1')
	
			else:
				quit()
		elif mode == 'sett':
			addon.setSetting('subs', 'NO') if wybor == 'YES' else addon.setSetting('subs', 'YES')
			xbmc.executebuiltin('Container.Refresh')	
				
	else:
		home()    
if __name__ == '__main__':
    router(sys.argv[2][1:])
