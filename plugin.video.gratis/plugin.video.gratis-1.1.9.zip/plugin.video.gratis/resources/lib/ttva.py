import re
import requests
from bs4 import BeautifulSoup

BASE_URL = 'https://thetvapp.to'
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36'
HEADERS = {"User-Agent": USER_AGENT, "Referer": BASE_URL}
SESSION = requests.Session()

def get_page(url: str, referer: str = '') -> str:
    if referer:
        HEADERS['Referer'] = referer
    return SESSION.get(url, headers=HEADERS).text

def get_soup(url: str, referer: str = '') -> BeautifulSoup:
    response = get_page(url, referer)
    return BeautifulSoup(response, 'html.parser')

def tvapp_main():
    items = []
    cats = get_soup(BASE_URL).find_all(class_='nav-link')
    for cat in cats[1:]:
        title = cat.text
        link = cat['href']
        items.append([title, link])
    return items

def sub_menu(url: str):
    items = []
    channels = get_soup(url).find_all(class_='list-group-item')
    for channel in channels:
        title = channel.text
        link = f"{BASE_URL}{channel['href']}"
        items.append([title, link])
    return items

def get_link(url: str) -> str:
    soup = get_soup(url)
    token = soup.find(attrs={'name': 'csrf-token'})['content']
    url2 = BASE_URL + re.findall('url: "(.+?)"', str(soup))[0]
    HEADERS['X-CSRF-TOKEN'] = token
    link = SESSION.post(url2, headers=HEADERS).text
    return f'{link}|Referer={BASE_URL}'

