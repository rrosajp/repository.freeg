import sys
from resources.lib.addon import router

if __name__=='__main__':
    router(sys.argv[2][1:])